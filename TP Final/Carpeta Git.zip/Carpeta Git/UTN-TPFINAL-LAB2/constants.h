// constants.h
#ifndef CONSTANTS_H
#define CONSTANTS_H


#define NUM_GENEROS 5
#define LIBROS_POR_GENERO 10

#endif // CONSTANTS_H
