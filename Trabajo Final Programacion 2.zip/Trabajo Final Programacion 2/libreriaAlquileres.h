#ifndef LIBRERIAALQUILERES_H_INCLUDED
#define LIBRERIAALQUILERES_H_INCLUDED

typedef struct nodoAlquiler
{
    stlibros datoLibro;
    lector datosLecto

    struct nodoAlquiler * siguiente ;
}nodoAlquiler;



#endif // LIBRERIAALQUILERES_H_INCLUDED
